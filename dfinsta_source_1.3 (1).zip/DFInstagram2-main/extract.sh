apktool d $1 -o instagram_source

